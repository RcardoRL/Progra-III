﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Grbdatospersonales = New System.Windows.Forms.GroupBox()
        Me.txtIdentificacion = New System.Windows.Forms.MaskedTextBox()
        Me.txtDireccion = New System.Windows.Forms.TextBox()
        Me.Lbldireccion = New System.Windows.Forms.Label()
        Me.Lblfechanacimiento = New System.Windows.Forms.Label()
        Me.Lblapellido2 = New System.Windows.Forms.Label()
        Me.Lblapellido1 = New System.Windows.Forms.Label()
        Me.Lblnombre = New System.Windows.Forms.Label()
        Me.Lblcorreo = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpfechanaci = New System.Windows.Forms.DateTimePicker()
        Me.txtCorreo = New System.Windows.Forms.TextBox()
        Me.txtSegundoApellido = New System.Windows.Forms.TextBox()
        Me.txtPrimerApellido = New System.Windows.Forms.TextBox()
        Me.txtNombre = New System.Windows.Forms.TextBox()
        Me.Cmbtipoid = New System.Windows.Forms.ComboBox()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.Btnsalir = New System.Windows.Forms.Button()
        Me.BtnConsultar = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Grbdatospersonales.SuspendLayout()
        Me.SuspendLayout()
        '
        'Grbdatospersonales
        '
        Me.Grbdatospersonales.Controls.Add(Me.txtIdentificacion)
        Me.Grbdatospersonales.Controls.Add(Me.txtDireccion)
        Me.Grbdatospersonales.Controls.Add(Me.Lbldireccion)
        Me.Grbdatospersonales.Controls.Add(Me.Lblfechanacimiento)
        Me.Grbdatospersonales.Controls.Add(Me.Lblapellido2)
        Me.Grbdatospersonales.Controls.Add(Me.Lblapellido1)
        Me.Grbdatospersonales.Controls.Add(Me.Lblnombre)
        Me.Grbdatospersonales.Controls.Add(Me.Lblcorreo)
        Me.Grbdatospersonales.Controls.Add(Me.Label2)
        Me.Grbdatospersonales.Controls.Add(Me.Label1)
        Me.Grbdatospersonales.Controls.Add(Me.dtpfechanaci)
        Me.Grbdatospersonales.Controls.Add(Me.txtCorreo)
        Me.Grbdatospersonales.Controls.Add(Me.txtSegundoApellido)
        Me.Grbdatospersonales.Controls.Add(Me.txtPrimerApellido)
        Me.Grbdatospersonales.Controls.Add(Me.txtNombre)
        Me.Grbdatospersonales.Controls.Add(Me.Cmbtipoid)
        Me.Grbdatospersonales.Font = New System.Drawing.Font("Segoe UI Emoji", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Grbdatospersonales.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Grbdatospersonales.Location = New System.Drawing.Point(47, 144)
        Me.Grbdatospersonales.Name = "Grbdatospersonales"
        Me.Grbdatospersonales.Size = New System.Drawing.Size(1065, 443)
        Me.Grbdatospersonales.TabIndex = 2
        Me.Grbdatospersonales.TabStop = False
        Me.Grbdatospersonales.Text = "CONSULTAS CIVILES"
        '
        'txtIdentificacion
        '
        Me.txtIdentificacion.Location = New System.Drawing.Point(319, 98)
        Me.txtIdentificacion.Name = "txtIdentificacion"
        Me.txtIdentificacion.Size = New System.Drawing.Size(245, 34)
        Me.txtIdentificacion.TabIndex = 1
        '
        'txtDireccion
        '
        Me.txtDireccion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDireccion.Location = New System.Drawing.Point(527, 302)
        Me.txtDireccion.Multiline = True
        Me.txtDireccion.Name = "txtDireccion"
        Me.txtDireccion.Size = New System.Drawing.Size(481, 81)
        Me.txtDireccion.TabIndex = 7
        '
        'Lbldireccion
        '
        Me.Lbldireccion.AutoSize = True
        Me.Lbldireccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbldireccion.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lbldireccion.Location = New System.Drawing.Point(522, 259)
        Me.Lbldireccion.Name = "Lbldireccion"
        Me.Lbldireccion.Size = New System.Drawing.Size(102, 25)
        Me.Lbldireccion.TabIndex = 14
        Me.Lbldireccion.Text = "Dirección"
        '
        'Lblfechanacimiento
        '
        Me.Lblfechanacimiento.AutoSize = True
        Me.Lblfechanacimiento.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblfechanacimiento.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lblfechanacimiento.Location = New System.Drawing.Point(24, 259)
        Me.Lblfechanacimiento.Name = "Lblfechanacimiento"
        Me.Lblfechanacimiento.Size = New System.Drawing.Size(212, 25)
        Me.Lblfechanacimiento.TabIndex = 13
        Me.Lblfechanacimiento.Text = "Fecha de nacimiento"
        '
        'Lblapellido2
        '
        Me.Lblapellido2.AutoSize = True
        Me.Lblapellido2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblapellido2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lblapellido2.Location = New System.Drawing.Point(640, 153)
        Me.Lblapellido2.Name = "Lblapellido2"
        Me.Lblapellido2.Size = New System.Drawing.Size(183, 25)
        Me.Lblapellido2.TabIndex = 12
        Me.Lblapellido2.Text = "Segundo Apellido"
        '
        'Lblapellido1
        '
        Me.Lblapellido1.AutoSize = True
        Me.Lblapellido1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblapellido1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lblapellido1.Location = New System.Drawing.Point(316, 154)
        Me.Lblapellido1.Name = "Lblapellido1"
        Me.Lblapellido1.Size = New System.Drawing.Size(158, 25)
        Me.Lblapellido1.TabIndex = 11
        Me.Lblapellido1.Text = "Primer Apellido"
        '
        'Lblnombre
        '
        Me.Lblnombre.AutoSize = True
        Me.Lblnombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblnombre.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lblnombre.Location = New System.Drawing.Point(24, 154)
        Me.Lblnombre.Name = "Lblnombre"
        Me.Lblnombre.Size = New System.Drawing.Size(87, 25)
        Me.Lblnombre.TabIndex = 10
        Me.Lblnombre.Text = "Nombre"
        '
        'Lblcorreo
        '
        Me.Lblcorreo.AutoSize = True
        Me.Lblcorreo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblcorreo.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lblcorreo.Location = New System.Drawing.Point(640, 56)
        Me.Lblcorreo.Name = "Lblcorreo"
        Me.Lblcorreo.Size = New System.Drawing.Size(191, 25)
        Me.Lblcorreo.TabIndex = 9
        Me.Lblcorreo.Text = "Correo Electrónico"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(314, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(139, 25)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Identificación"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(24, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(217, 25)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Tipo de identificación"
        '
        'dtpfechanaci
        '
        Me.dtpfechanaci.Location = New System.Drawing.Point(29, 302)
        Me.dtpfechanaci.Name = "dtpfechanaci"
        Me.dtpfechanaci.Size = New System.Drawing.Size(402, 34)
        Me.dtpfechanaci.TabIndex = 6
        '
        'txtCorreo
        '
        Me.txtCorreo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCorreo.Location = New System.Drawing.Point(645, 96)
        Me.txtCorreo.Name = "txtCorreo"
        Me.txtCorreo.Size = New System.Drawing.Size(363, 34)
        Me.txtCorreo.TabIndex = 2
        '
        'txtSegundoApellido
        '
        Me.txtSegundoApellido.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSegundoApellido.Location = New System.Drawing.Point(645, 187)
        Me.txtSegundoApellido.Name = "txtSegundoApellido"
        Me.txtSegundoApellido.Size = New System.Drawing.Size(246, 34)
        Me.txtSegundoApellido.TabIndex = 5
        '
        'txtPrimerApellido
        '
        Me.txtPrimerApellido.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPrimerApellido.Location = New System.Drawing.Point(319, 187)
        Me.txtPrimerApellido.Name = "txtPrimerApellido"
        Me.txtPrimerApellido.Size = New System.Drawing.Size(235, 34)
        Me.txtPrimerApellido.TabIndex = 4
        '
        'txtNombre
        '
        Me.txtNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNombre.Location = New System.Drawing.Point(29, 187)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(235, 34)
        Me.txtNombre.TabIndex = 3
        '
        'Cmbtipoid
        '
        Me.Cmbtipoid.FormattingEnabled = True
        Me.Cmbtipoid.Items.AddRange(New Object() {"Nacional", "Dimex", "Pasaporte"})
        Me.Cmbtipoid.Location = New System.Drawing.Point(29, 95)
        Me.Cmbtipoid.Name = "Cmbtipoid"
        Me.Cmbtipoid.Size = New System.Drawing.Size(178, 35)
        Me.Cmbtipoid.TabIndex = 0
        '
        'btnLimpiar
        '
        Me.btnLimpiar.BackColor = System.Drawing.Color.Transparent
        Me.btnLimpiar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnLimpiar.FlatAppearance.BorderSize = 0
        Me.btnLimpiar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.btnLimpiar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLimpiar.Font = New System.Drawing.Font("Segoe UI Emoji", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLimpiar.Image = CType(resources.GetObject("btnLimpiar.Image"), System.Drawing.Image)
        Me.btnLimpiar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnLimpiar.Location = New System.Drawing.Point(1130, 369)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(118, 43)
        Me.btnLimpiar.TabIndex = 11
        Me.btnLimpiar.Text = "Borrar"
        Me.btnLimpiar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLimpiar.UseVisualStyleBackColor = False
        '
        'Btnsalir
        '
        Me.Btnsalir.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Btnsalir.BackColor = System.Drawing.Color.Transparent
        Me.Btnsalir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Btnsalir.FlatAppearance.BorderSize = 0
        Me.Btnsalir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.Btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnsalir.Font = New System.Drawing.Font("Segoe UI Emoji", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnsalir.ForeColor = System.Drawing.Color.Black
        Me.Btnsalir.Image = CType(resources.GetObject("Btnsalir.Image"), System.Drawing.Image)
        Me.Btnsalir.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btnsalir.Location = New System.Drawing.Point(1128, 312)
        Me.Btnsalir.Name = "Btnsalir"
        Me.Btnsalir.Size = New System.Drawing.Size(118, 42)
        Me.Btnsalir.TabIndex = 9
        Me.Btnsalir.Text = "Inicio"
        Me.Btnsalir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btnsalir.UseVisualStyleBackColor = False
        '
        'BtnConsultar
        '
        Me.BtnConsultar.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.BtnConsultar.BackColor = System.Drawing.Color.Transparent
        Me.BtnConsultar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.BtnConsultar.FlatAppearance.BorderSize = 0
        Me.BtnConsultar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnConsultar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.BtnConsultar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnConsultar.Font = New System.Drawing.Font("Segoe UI Emoji", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnConsultar.ForeColor = System.Drawing.Color.Black
        Me.BtnConsultar.Image = CType(resources.GetObject("BtnConsultar.Image"), System.Drawing.Image)
        Me.BtnConsultar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnConsultar.Location = New System.Drawing.Point(1128, 247)
        Me.BtnConsultar.Name = "BtnConsultar"
        Me.BtnConsultar.Size = New System.Drawing.Size(118, 43)
        Me.BtnConsultar.TabIndex = 9
        Me.BtnConsultar.Text = "Buscar"
        Me.BtnConsultar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnConsultar.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(47, 17)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(188, 115)
        Me.Button1.TabIndex = 12
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.RosyBrown
        Me.ClientSize = New System.Drawing.Size(1285, 609)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Controls.Add(Me.Btnsalir)
        Me.Controls.Add(Me.BtnConsultar)
        Me.Controls.Add(Me.Grbdatospersonales)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.Grbdatospersonales.ResumeLayout(False)
        Me.Grbdatospersonales.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Grbdatospersonales As GroupBox
    Friend WithEvents txtIdentificacion As MaskedTextBox
    Friend WithEvents txtDireccion As TextBox
    Friend WithEvents Lbldireccion As Label
    Friend WithEvents Lblfechanacimiento As Label
    Friend WithEvents Lblapellido2 As Label
    Friend WithEvents Lblapellido1 As Label
    Friend WithEvents Lblnombre As Label
    Friend WithEvents Lblcorreo As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents dtpfechanaci As DateTimePicker
    Friend WithEvents txtCorreo As TextBox
    Friend WithEvents txtSegundoApellido As TextBox
    Friend WithEvents txtPrimerApellido As TextBox
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents Cmbtipoid As ComboBox
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents Btnsalir As Button
    Friend WithEvents BtnConsultar As Button
    Friend WithEvents Button1 As Button
End Class
