﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmMenu
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMenu))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MantenimientoCiudadanosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsulaDeCiudadanoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MóduloSeguridadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InclusiónDeCódigoUsuarioYClaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModificaciónDeDatosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.txtFecha = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BtnVote = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MantenimientoCiudadanosToolStripMenuItem, Me.MóduloSeguridadToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1159, 28)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MantenimientoCiudadanosToolStripMenuItem
        '
        Me.MantenimientoCiudadanosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConsulaDeCiudadanoToolStripMenuItem})
        Me.MantenimientoCiudadanosToolStripMenuItem.Name = "MantenimientoCiudadanosToolStripMenuItem"
        Me.MantenimientoCiudadanosToolStripMenuItem.Size = New System.Drawing.Size(183, 24)
        Me.MantenimientoCiudadanosToolStripMenuItem.Text = "Consulta de Ciudadanos"
        '
        'ConsulaDeCiudadanoToolStripMenuItem
        '
        Me.ConsulaDeCiudadanoToolStripMenuItem.Name = "ConsulaDeCiudadanoToolStripMenuItem"
        Me.ConsulaDeCiudadanoToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.ConsulaDeCiudadanoToolStripMenuItem.Text = "Consulta por cédula"
        '
        'MóduloSeguridadToolStripMenuItem
        '
        Me.MóduloSeguridadToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InclusiónDeCódigoUsuarioYClaveToolStripMenuItem, Me.ModificaciónDeDatosToolStripMenuItem})
        Me.MóduloSeguridadToolStripMenuItem.Name = "MóduloSeguridadToolStripMenuItem"
        Me.MóduloSeguridadToolStripMenuItem.Size = New System.Drawing.Size(147, 24)
        Me.MóduloSeguridadToolStripMenuItem.Text = "Módulo Seguridad"
        '
        'InclusiónDeCódigoUsuarioYClaveToolStripMenuItem
        '
        Me.InclusiónDeCódigoUsuarioYClaveToolStripMenuItem.Name = "InclusiónDeCódigoUsuarioYClaveToolStripMenuItem"
        Me.InclusiónDeCódigoUsuarioYClaveToolStripMenuItem.Size = New System.Drawing.Size(286, 26)
        Me.InclusiónDeCódigoUsuarioYClaveToolStripMenuItem.Text = "Ingresar como Administrador"
        '
        'ModificaciónDeDatosToolStripMenuItem
        '
        Me.ModificaciónDeDatosToolStripMenuItem.Name = "ModificaciónDeDatosToolStripMenuItem"
        Me.ModificaciónDeDatosToolStripMenuItem.Size = New System.Drawing.Size(286, 26)
        Me.ModificaciónDeDatosToolStripMenuItem.Text = "Modificación de datos"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(52, 24)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'txtFecha
        '
        Me.txtFecha.Location = New System.Drawing.Point(887, 4)
        Me.txtFecha.Name = "txtFecha"
        Me.txtFecha.Size = New System.Drawing.Size(225, 22)
        Me.txtFecha.TabIndex = 9
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.ErrorImage = Nothing
        Me.PictureBox1.InitialImage = Nothing
        Me.PictureBox1.Location = New System.Drawing.Point(0, 28)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1159, 688)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'BtnVote
        '
        Me.BtnVote.BackColor = System.Drawing.Color.Transparent
        Me.BtnVote.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.BtnVote.FlatAppearance.BorderSize = 0
        Me.BtnVote.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnVote.ForeColor = System.Drawing.Color.Transparent
        Me.BtnVote.Image = CType(resources.GetObject("BtnVote.Image"), System.Drawing.Image)
        Me.BtnVote.Location = New System.Drawing.Point(966, 62)
        Me.BtnVote.Name = "BtnVote"
        Me.BtnVote.Size = New System.Drawing.Size(161, 154)
        Me.BtnVote.TabIndex = 11
        Me.BtnVote.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnVote.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Emoji", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label2.Location = New System.Drawing.Point(12, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(655, 57)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Tribunal Supremo de Elecciones"
        '
        'FrmMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gainsboro
        Me.ClientSize = New System.Drawing.Size(1159, 716)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.BtnVote)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txtFecha)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmMenu"
        Me.Text = "FrmMenu"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents MantenimientoCiudadanosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MóduloSeguridadToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InclusiónDeCódigoUsuarioYClaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Timer1 As Timer
    Friend WithEvents txtFecha As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ConsulaDeCiudadanoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BtnVote As Button
    Friend WithEvents ModificaciónDeDatosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label2 As Label
End Class
