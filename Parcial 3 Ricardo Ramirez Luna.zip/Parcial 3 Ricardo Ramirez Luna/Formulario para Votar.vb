﻿Public Class Formulario_para_Votar

    ' Variables para contar los votos

    Private VotosPAC As Integer = 0
    Private VotosRestauracionNacional As Integer = 0
    Private VotosFrenteAmplio As Integer = 0
    Private VotosLiberacion As Integer = 0
    Private VotosUnionCristiana As Integer = 0
    Private VotosMovimientoLibertario As Integer = 0
    Private VotosUnionNacional As Integer = 0

    Private cedulasVotadas As New HashSet(Of String)
    Private Sub Formulario_para_Votar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Inicializar etiquetas de votos

        Label2.Text = VotosPAC.ToString()
        Label3.Text = VotosRestauracionNacional.ToString()
        Label4.Text = VotosFrenteAmplio.ToString()
        Label5.Text = VotosLiberacion.ToString()
        Label6.Text = VotosUnionCristiana.ToString()
        Label7.Text = VotosMovimientoLibertario.ToString()
        Label8.Text = VotosUnionNacional.ToString()

    End Sub

    ' Función para verificar cédula y registrar voto
    Private Sub RegistrarVoto(ByRef votos As Integer, ByRef label As Label)
        Dim cedula As String = InputBox("Por favor ingrese su cédula:", "Verificación de cédula")
        If cedula <> "" Then
            If cedulasVotadas.Contains(cedula) Then
                MessageBox.Show("Esta cédula ya ha votado.", "Voto no permitido", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Else
                cedulasVotadas.Add(cedula)
                votos += 1
                label.Text = votos.ToString()
            End If
        Else
            MessageBox.Show("Debe ingresar una cédula válida.", "Cédula inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub
    Private Sub BtnPAC_Click(sender As Object, e As EventArgs) Handles BtnPAC.Click
        RegistrarVoto(VotosPAC, Label2)
    End Sub

    Private Sub BtnRestauracionNacional_Click(sender As Object, e As EventArgs) Handles BtnRestauracionNacional.Click
        RegistrarVoto(VotosRestauracionNacional, Label3)
    End Sub

    Private Sub BtnFrendeAmplio_Click(sender As Object, e As EventArgs) Handles BtnFrendeAmplio.Click
        RegistrarVoto(VotosFrenteAmplio, Label4)
    End Sub

    Private Sub BtnLiberacion_Click(sender As Object, e As EventArgs) Handles BtnLiberacion.Click
        RegistrarVoto(VotosLiberacion, Label5)
    End Sub

    Private Sub BtnUnionCristiana_Click(sender As Object, e As EventArgs) Handles BtnUnionCristiana.Click
        RegistrarVoto(VotosUnionCristiana, Label6)
    End Sub

    Private Sub BtnMovimientoLibertario_Click(sender As Object, e As EventArgs) Handles BtnMovimientoLibertario.Click
        RegistrarVoto(VotosMovimientoLibertario, Label7)
    End Sub

    Private Sub BtnUnionNacional_Click(sender As Object, e As EventArgs) Handles BtnUnionNacional.Click
        RegistrarVoto(VotosUnionNacional, Label8)
    End Sub

    Private Sub Btnsalir_Click(sender As Object, e As EventArgs) Handles Btnsalir.Click
        Me.Close()
        FrmMenu.Show()
    End Sub
End Class