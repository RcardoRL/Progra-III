﻿
Imports System.Data.SqlClient
Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Security.Cryptography
Imports System.Text
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

' Se realiza conexión a la Base de datos
Public Class Conexion
    Public Conexion As SqlConnection = New SqlConnection("Data source=DELL50120595P\SQLEXPRESS;Initial Catalog = Datos Ciudadanos;Trusted_connection=Yes")
    Public comando As SqlCommand
    Public da As SqlDataAdapter
    Public ds As DataSet = New DataSet()
    Public builder As SqlCommandBuilder

    ' Metodo para abrir la Base de datos
    Public Sub conectar()
        Try
            Conexion.Open()
            MessageBox.Show("Conexión Exitosa!!")
        Catch ex As Exception
            MessageBox.Show("Error: " + ex.ToString)
        Finally
            Conexion.Close()
        End Try
    End Sub

    Public Function validar_correo(ByRef e As String) As Boolean
        Try
            Return Regex.IsMatch(e.Trim, "^([0-9a-zA-Z]([-\.\w]*([0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]\.)+[a-zA-Z]{2,9})$")
        Catch ex As Exception
            MsgBox(ex.ToString)
            Return False
        End Try
    End Function

    ' Se valida si el número de cédula existe
    Public Function valida_id(ByVal vtipoid As String, ByVal vnumeroid As String) As DataTable
        Dim dt = New DataTable()

        Consultar("SELECT * FROM PERSONA WHERE TIPO_ID = '" + vtipoid.ToString() + "' AND IDENTIFICACION = '" + vnumeroid + "'", "PERSONA")
        If ds.Tables("PERSONA").Rows.Count > 0 Then
            f = 0
        Else
            f = 1
        End If
        da.Fill(dt)
        Return dt
    End Function

    ' Consulta en la Base de datos si existe el usuario
    Public Function valida_usuario(ByVal vusuario As String) As Boolean
        Dim dt = New DataTable()
        Consultar("SELECT * FROM USUARIO WHERE USUARIO = '" & vusuario & "'", "USUARIO")
        Return ds.Tables("USUARIO").Rows.Count > 0
    End Function

    ' Limpia la tabla donde se guarda la info y guarda los nuevos datos de consulta
    Public Sub Consultar(ByVal sql As String, ByVal tabla As String)
        ds.Tables.Clear()
        da = New SqlDataAdapter(sql, Conexion)
        builder = New SqlCommandBuilder(da)
        da.Fill(ds, tabla)
    End Sub

    ' Se inserta los datos en la Base de datos
    Public Function inserta_datos(ByVal datos As String) As Boolean
        Try
            Conexion.Open()
            comando = New SqlCommand(datos, Conexion)
            comando.ExecuteNonQuery()
            Conexion.Close()
            f = 0
            Return True
        Catch ex As Exception
            MessageBox.Show("Error: " + ex.ToString)
            f = 1
            Return False
        Finally
            Conexion.Close()
        End Try
    End Function

    Public Function Encriptar_clave(clave As String) As String
        Dim SHA256 As SHA256 = SHA256Managed.Create()
        Dim bytes As Byte() = Encoding.UTF8.GetBytes(clave)
        Dim hash As Byte() = SHA256.ComputeHash(bytes)
        Dim StringBuilder As New StringBuilder()
        For i As Integer = 0 To hash.Length - 1
            StringBuilder.Append(hash(i).ToString("X2"))
        Next
        Return StringBuilder.ToString()
    End Function

    Public Function Desencriptar_clave(vclave As String) As String
        Dim SHA256 As SHA256 = SHA256Managed.Create()
        Dim hashbytes As Byte() = Encoding.UTF8.GetBytes(vclave)
        Dim decryptedBytes As Byte() = SHA256.ComputeHash(hashbytes)
        Dim decryptebuilder As New StringBuilder()
        For i As Integer = 0 To decryptedBytes.Length - 1
            decryptebuilder.Append(decryptedBytes(i).ToString("X2"))
        Next
        Return decryptebuilder.ToString()
    End Function
End Class
