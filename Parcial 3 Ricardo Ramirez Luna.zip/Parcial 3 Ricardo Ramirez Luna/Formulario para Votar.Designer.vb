﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Formulario_para_Votar
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Formulario_para_Votar))
        Me.Grbdatospersonales = New System.Windows.Forms.GroupBox()
        Me.BtnPAC = New System.Windows.Forms.Button()
        Me.BtnFrendeAmplio = New System.Windows.Forms.Button()
        Me.BtnLiberacion = New System.Windows.Forms.Button()
        Me.BtnMovimientoLibertario = New System.Windows.Forms.Button()
        Me.BtnRestauracionNacional = New System.Windows.Forms.Button()
        Me.BtnUnionCristiana = New System.Windows.Forms.Button()
        Me.BtnUnionNacional = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Btnsalir = New System.Windows.Forms.Button()
        Me.Grbdatospersonales.SuspendLayout()
        Me.SuspendLayout()
        '
        'Grbdatospersonales
        '
        Me.Grbdatospersonales.Controls.Add(Me.Label6)
        Me.Grbdatospersonales.Controls.Add(Me.Label7)
        Me.Grbdatospersonales.Controls.Add(Me.Label8)
        Me.Grbdatospersonales.Controls.Add(Me.Label4)
        Me.Grbdatospersonales.Controls.Add(Me.Label5)
        Me.Grbdatospersonales.Controls.Add(Me.Label3)
        Me.Grbdatospersonales.Controls.Add(Me.Label2)
        Me.Grbdatospersonales.Controls.Add(Me.Label1)
        Me.Grbdatospersonales.Controls.Add(Me.BtnUnionCristiana)
        Me.Grbdatospersonales.Controls.Add(Me.BtnRestauracionNacional)
        Me.Grbdatospersonales.Controls.Add(Me.BtnMovimientoLibertario)
        Me.Grbdatospersonales.Controls.Add(Me.BtnLiberacion)
        Me.Grbdatospersonales.Controls.Add(Me.BtnFrendeAmplio)
        Me.Grbdatospersonales.Controls.Add(Me.BtnPAC)
        Me.Grbdatospersonales.Font = New System.Drawing.Font("Segoe UI Emoji", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Grbdatospersonales.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Grbdatospersonales.Location = New System.Drawing.Point(12, 12)
        Me.Grbdatospersonales.Name = "Grbdatospersonales"
        Me.Grbdatospersonales.Size = New System.Drawing.Size(567, 753)
        Me.Grbdatospersonales.TabIndex = 3
        Me.Grbdatospersonales.TabStop = False
        Me.Grbdatospersonales.Text = "SELECCIONE EL PARTIDO DE SU PREFERENCIA"
        '
        'BtnPAC
        '
        Me.BtnPAC.FlatAppearance.BorderSize = 0
        Me.BtnPAC.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPAC.Image = CType(resources.GetObject("BtnPAC.Image"), System.Drawing.Image)
        Me.BtnPAC.Location = New System.Drawing.Point(22, 66)
        Me.BtnPAC.Name = "BtnPAC"
        Me.BtnPAC.Size = New System.Drawing.Size(213, 94)
        Me.BtnPAC.TabIndex = 0
        Me.BtnPAC.UseVisualStyleBackColor = True
        '
        'BtnFrendeAmplio
        '
        Me.BtnFrendeAmplio.FlatAppearance.BorderSize = 0
        Me.BtnFrendeAmplio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFrendeAmplio.Image = CType(resources.GetObject("BtnFrendeAmplio.Image"), System.Drawing.Image)
        Me.BtnFrendeAmplio.Location = New System.Drawing.Point(22, 255)
        Me.BtnFrendeAmplio.Name = "BtnFrendeAmplio"
        Me.BtnFrendeAmplio.Size = New System.Drawing.Size(213, 82)
        Me.BtnFrendeAmplio.TabIndex = 1
        Me.BtnFrendeAmplio.UseVisualStyleBackColor = True
        '
        'BtnLiberacion
        '
        Me.BtnLiberacion.FlatAppearance.BorderSize = 0
        Me.BtnLiberacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnLiberacion.Image = CType(resources.GetObject("BtnLiberacion.Image"), System.Drawing.Image)
        Me.BtnLiberacion.Location = New System.Drawing.Point(22, 351)
        Me.BtnLiberacion.Name = "BtnLiberacion"
        Me.BtnLiberacion.Size = New System.Drawing.Size(213, 82)
        Me.BtnLiberacion.TabIndex = 2
        Me.BtnLiberacion.UseVisualStyleBackColor = True
        '
        'BtnMovimientoLibertario
        '
        Me.BtnMovimientoLibertario.FlatAppearance.BorderSize = 0
        Me.BtnMovimientoLibertario.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnMovimientoLibertario.Image = CType(resources.GetObject("BtnMovimientoLibertario.Image"), System.Drawing.Image)
        Me.BtnMovimientoLibertario.Location = New System.Drawing.Point(22, 547)
        Me.BtnMovimientoLibertario.Name = "BtnMovimientoLibertario"
        Me.BtnMovimientoLibertario.Size = New System.Drawing.Size(213, 82)
        Me.BtnMovimientoLibertario.TabIndex = 3
        Me.BtnMovimientoLibertario.UseVisualStyleBackColor = True
        '
        'BtnRestauracionNacional
        '
        Me.BtnRestauracionNacional.FlatAppearance.BorderSize = 0
        Me.BtnRestauracionNacional.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRestauracionNacional.Image = CType(resources.GetObject("BtnRestauracionNacional.Image"), System.Drawing.Image)
        Me.BtnRestauracionNacional.Location = New System.Drawing.Point(22, 164)
        Me.BtnRestauracionNacional.Name = "BtnRestauracionNacional"
        Me.BtnRestauracionNacional.Size = New System.Drawing.Size(213, 82)
        Me.BtnRestauracionNacional.TabIndex = 4
        Me.BtnRestauracionNacional.UseVisualStyleBackColor = True
        '
        'BtnUnionCristiana
        '
        Me.BtnUnionCristiana.FlatAppearance.BorderSize = 0
        Me.BtnUnionCristiana.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnUnionCristiana.Image = CType(resources.GetObject("BtnUnionCristiana.Image"), System.Drawing.Image)
        Me.BtnUnionCristiana.Location = New System.Drawing.Point(22, 451)
        Me.BtnUnionCristiana.Name = "BtnUnionCristiana"
        Me.BtnUnionCristiana.Size = New System.Drawing.Size(213, 82)
        Me.BtnUnionCristiana.TabIndex = 5
        Me.BtnUnionCristiana.UseVisualStyleBackColor = True
        '
        'BtnUnionNacional
        '
        Me.BtnUnionNacional.FlatAppearance.BorderSize = 0
        Me.BtnUnionNacional.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnUnionNacional.Image = CType(resources.GetObject("BtnUnionNacional.Image"), System.Drawing.Image)
        Me.BtnUnionNacional.Location = New System.Drawing.Point(34, 653)
        Me.BtnUnionNacional.Name = "BtnUnionNacional"
        Me.BtnUnionNacional.Size = New System.Drawing.Size(213, 82)
        Me.BtnUnionNacional.TabIndex = 6
        Me.BtnUnionNacional.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Image = CType(resources.GetObject("Button8.Image"), System.Drawing.Image)
        Me.Button8.Location = New System.Drawing.Point(688, 603)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(200, 132)
        Me.Button8.TabIndex = 7
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(302, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(194, 27)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Cantidad de votos:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(351, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(24, 27)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(351, 183)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(24, 27)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "0"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(351, 379)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(24, 27)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(351, 283)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(24, 27)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(351, 479)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(24, 27)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(351, 575)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(24, 27)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(351, 665)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(24, 27)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "0"
        '
        'Btnsalir
        '
        Me.Btnsalir.FlatAppearance.BorderSize = 0
        Me.Btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnsalir.Font = New System.Drawing.Font("Segoe UI Emoji", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnsalir.Image = CType(resources.GetObject("Btnsalir.Image"), System.Drawing.Image)
        Me.Btnsalir.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btnsalir.Location = New System.Drawing.Point(774, 36)
        Me.Btnsalir.Name = "Btnsalir"
        Me.Btnsalir.Size = New System.Drawing.Size(114, 65)
        Me.Btnsalir.TabIndex = 8
        Me.Btnsalir.Text = "Inicio"
        Me.Btnsalir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btnsalir.UseVisualStyleBackColor = True
        '
        'Formulario_para_Votar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ClientSize = New System.Drawing.Size(908, 777)
        Me.Controls.Add(Me.Btnsalir)
        Me.Controls.Add(Me.BtnUnionNacional)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Grbdatospersonales)
        Me.Name = "Formulario_para_Votar"
        Me.Text = "Formulario_para_Votar"
        Me.Grbdatospersonales.ResumeLayout(False)
        Me.Grbdatospersonales.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Grbdatospersonales As GroupBox
    Friend WithEvents Button8 As Button
    Friend WithEvents BtnUnionNacional As Button
    Friend WithEvents BtnUnionCristiana As Button
    Friend WithEvents BtnRestauracionNacional As Button
    Friend WithEvents BtnMovimientoLibertario As Button
    Friend WithEvents BtnLiberacion As Button
    Friend WithEvents BtnFrendeAmplio As Button
    Friend WithEvents BtnPAC As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Btnsalir As Button
End Class
