﻿Public Class Form1
    Dim Conexion As Conexion = New Conexion()

    ' Esta línea de código carga datos en la tabla 'Datos_CiudadanosDataSet.PERSONA' Puede moverla o quitarla según sea necesario.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Me.PERSONATableAdapter.Fill(Me.Datos_CiudadanosDataSet.PERSONA)
        Conexion.conectar()
    End Sub
    Private Sub Btnsalir_Click(sender As Object, e As EventArgs) Handles Btnsalir.Click
        Me.Close()
        FrmMenu.Show()
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ' Brinda la fecha actual
        Txtfecha.Text = Now
    End Sub

    ' Se crea procedimiento para identificar el tipo de identificación
    Private Sub Cmbtipoid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cmbtipoid.SelectedIndexChanged
        txtIdentificacion.Text = ""
        If Cmbtipoid.Text = "Nacional" Then
            ntipoid = 1
            txtIdentificacion.Mask = "9-9999-9999"
            SendKeys.Send("{tab}")   'Envía un tab al siguiente campo

        ElseIf Cmbtipoid.Text = "Dimex" Then
            ntipoid = 2
            txtIdentificacion.Mask = "999999999999"
            SendKeys.Send("{tab}")

        ElseIf Cmbtipoid.Text = "Pasaporte" Then
            ntipoid = 3
            txtIdentificacion.Mask = "AAAAAAAAAAAAAAAAAAAA"
            SendKeys.Send("{tab}")
        End If
    End Sub

    ' Se restringe a que el usuario solo pueda digitar letras
    Private Sub txtNombre_KeyPress(sender As Object, e As EventArgs) Handles txtNombre.KeyPress
        set_solo_letras(e)
    End Sub
    Private Sub txtPrimerApellido_KeyPress(sender As Object, e As EventArgs) Handles txtPrimerApellido.KeyPress
        set_solo_letras(e)
    End Sub
    Private Sub txtSegundoApellido_KeyPress(sender As Object, e As EventArgs) Handles txtSegundoApellido.KeyPress
        set_solo_letras(e)
    End Sub
    Private Sub btninsertar_Click(sender As Object, e As EventArgs) Handles btninsertar.Click

        ' Definicion de variables

        Dim vtipoid As Integer
        vtipoid = 0
        Dim vnumeroid, vnombre, vapellido1, vapellido2, vcorreo, vfechanaci, vdireccion, valorformateado, valorsinformato, strsql As String

        ' Inicializar variable

        vnumeroid = ""
        vnombre = ""
        vapellido1 = ""
        vapellido2 = ""
        vcorreo = ""
        vfechanaci = ""
        vdireccion = ""
        valorformateado = ""
        valorsinformato = ""
        strsql = ""
        Try
            If validar_campos() = False Then
                MsgBox("Datos incompletos, favor completar")
                Return
            Else
                If MessageBox.Show("Está seguro de Guardar el registro en la Base de Datos", "Confirmacion", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = Windows.Forms.DialogResult.Yes Then

                    ' Acá se elimina los guiones en el id

                    valorformateado = txtIdentificacion.Text
                    valorsinformato = valorformateado.Replace("-", "")
                    vnumeroid = valorsinformato
                    vtipoid = ntipoid
                    vnombre = txtNombre.Text
                    vapellido1 = txtPrimerApellido.Text
                    vapellido2 = txtSegundoApellido.Text
                    vcorreo = txtCorreo.Text
                    vfechanaci = dtpfechanaci.Value
                    vdireccion = txtDireccion.Text

                    ' Crear metodo validar la identificación antes de insertar

                    Dim dt = Conexion.valida_id(vtipoid, vnumeroid)
                    If f = 0 Then
                        MsgBox("Registro existe en la Base de Datos, no puede insertarlo")
                        Return
                    End If

                    ' Creamos el INSERT en la Base de datos

                    strsql = "INSERT INTO PERSONA (TIPO_ID, IDENTIFICACION, NOMBRE, PRIMER_APELLIDO, SEGUNDO_APELLIDO, CORREO_ELECTRONICO, FECHA_NACIMIENTO, DIRECCION)"
                    strsql += vbCrLf + "VALUES ('" & vtipoid & "','" & vnumeroid & "','" & vnombre & "','" & vapellido1 & "','" & vapellido2 & "','" & vcorreo & "','" & vfechanaci & "','" & vdireccion & "')"
                    MsgBox(strsql)
                    Conexion.inserta_datos(strsql)
                    If f = 0 Then
                        MessageBox.Show("Datos almacenados satisfactoriamente", "Datos guardados", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Me.PERSONATableAdapter.Fill(Me.Datos_CiudadanosDataSet.PERSONA)
                    Else
                        MessageBox.Show("Error al insertar datos", "Datos no guardados", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error:" + ex.ToString)
        End Try
    End Sub

    ' Se valida si los datos están completos
    Private Function validar_campos() As Boolean
        If Cmbtipoid.Text = "" Or txtIdentificacion.MaskFull = False Or txtNombre.Text = "" Or txtPrimerApellido.Text = "" Or txtDireccion.Text = "" Or txtCorreo.Text = "" Then
            Return False
        Else
            Return True
        End If
    End Function

    ' Se restringe a que realice una consulta antes de modificar o eliminar cualquier dato
    Private Sub Btneliminar_Click(sender As Object, e As EventArgs) Handles Btneliminar.Click
        Try
            If k = 0 Then
                MsgBox("Debe presionar el botón de Consultar antes de Eliminar")
                Return
            Else
                Dim vnumeroid, strsql, valorformateado, valorsinformato As String
                Dim vtipoid As Integer
                vtipoid = 0
                vnumeroid = ""
                strsql = ""
                valorformateado = ""
                valorsinformato = ""

                If MessageBox.Show("Está seguro de eliminar el registro en la Base de Datos", "confirmacion", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = Windows.Forms.DialogResult.Yes Then
                    valorformateado = txtIdentificacion.Text
                    valorsinformato = valorformateado.Replace("-", "")
                    vnumeroid = valorsinformato
                    vtipoid = ntipoid

                    ' Se crea el código para eliminar en la base de datos verificando el id

                    strsql = "DELETE FROM PERSONA WHERE TIPO_ID = " & vtipoid & " AND IDENTIFICACION = '" & vnumeroid & "'"
                    MsgBox(strsql)
                    Conexion.inserta_datos(strsql)
                    If f = 0 Then
                        MessageBox.Show("Registro Eliminado Satisfactoriamente")
                        Me.PERSONATableAdapter.Fill(Me.Datos_CiudadanosDataSet.PERSONA)
                    Else
                        MessageBox.Show("Error al Eliminar el Registro")
                    End If
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " + ex.ToString)
        End Try
    End Sub
    Private Sub Btnconsultar_Click(sender As Object, e As EventArgs) Handles Btnconsultar.Click
        Try
            If Cmbtipoid.Text = "" Or txtIdentificacion.MaskFull = False Then
                MsgBox("Datos Incompletos, favor completar")
                Return
            End If
            Dim vtipoid, videntificacion As String
            Dim valorformateado As String
            vtipoid = ""
            videntificacion = ""
            valorformateado = txtIdentificacion.Text
            Dim valorsinformato As String = valorformateado.Replace("-", "")
            videntificacion = valorsinformato
            vtipoid = ntipoid
            If valorsinformato.Trim <> "" Then
                Dim dt = Conexion.valida_id(vtipoid, videntificacion)
                If f = 1 Then
                    MsgBox("Número de identificacion no existe en la Base de Datos")
                    txtIdentificacion.Focus()
                    Return
                Else
                    k = 1
                    txtNombre.Text = dt.Rows(0)!nombre
                    txtPrimerApellido.Text = dt.Rows(0)!primer_apellido
                    txtSegundoApellido.Text = dt.Rows(0)!segundo_apellido
                    txtCorreo.Text = dt.Rows(0)!correo_electronico
                    dtpfechanaci.Value = dt.Rows(0)!fecha_nacimiento
                    txtDireccion.Text = dt.Rows(0)!direccion
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " + ex.ToString)
        End Try
    End Sub

    Private Sub Btnmodificar_Click(sender As Object, e As EventArgs) Handles Btnmodificar.Click
        Try
            If k = 0 Then
                MsgBox("Debe presionar el botón de Consultar antes de modificar")
                Return
            Else
                Dim vnumeroid, vnombre, vapellido1, vapellido2, vcorreo, vfechanaci, vdireccion, valorformateado, valorsinformato, vtipoid, strsql As String
                vnumeroid = ""
                vnombre = ""
                vapellido1 = ""
                vapellido2 = ""
                vcorreo = ""
                vfechanaci = ""
                vdireccion = ""
                valorformateado = ""
                valorsinformato = ""
                vtipoid = ""
                strsql = ""
                If validar_campos() = True Then
                    If MessageBox.Show("Estás seguro de Modificar el registro en la Base de Datos?", "Confirmacion", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = Windows.Forms.DialogResult.Yes Then
                        valorformateado = txtIdentificacion.Text
                        valorsinformato = valorformateado.Replace("-", "")
                        vnumeroid = valorsinformato
                        vtipoid = ntipoid
                        vnombre = txtNombre.Text
                        vapellido1 = txtPrimerApellido.Text
                        vapellido2 = txtSegundoApellido.Text
                        vcorreo = txtCorreo.Text
                        vfechanaci = dtpfechanaci.Value
                        vdireccion = txtDireccion.Text

                        ' Se actualiza los datos en la Base de datos

                        strsql = "UPDATE PERSONA SET NOMBRE = '" & vnombre & "', PRIMER_APELLIDO = '" & vapellido1 & "', SEGUNDO_APELLIDO = '" & vapellido2 & "', CORREO_ELECTRONICO = '" & vcorreo & "', FECHA_NACIMIENTO = '" & vfechanaci & "', DIRECCION = '" & vdireccion & "' WHERE TIPO_ID = " & vtipoid & " AND IDENTIFICACION = '" & vnumeroid & "'"
                        Conexion.inserta_datos(strsql)
                        If f = 0 Then
                            MessageBox.Show("Datos Modificados Satisfactoriamente!")
                            Me.PERSONATableAdapter.Fill(Me.Datos_CiudadanosDataSet.PERSONA)
                        Else
                            MessageBox.Show("Error al actualizar los datos!")
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub

    ' Se limpia todos los cambios
    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtIdentificacion.Clear()
        txtCorreo.Clear()
        txtNombre.Clear()
        txtPrimerApellido.Clear()
        txtSegundoApellido.Clear()
        txtDireccion.Clear()
    End Sub

    Private Sub Grbdatospersonales_Enter(sender As Object, e As EventArgs) Handles Grbdatospersonales.Enter
        Me.ControlBox = False
    End Sub

End Class
