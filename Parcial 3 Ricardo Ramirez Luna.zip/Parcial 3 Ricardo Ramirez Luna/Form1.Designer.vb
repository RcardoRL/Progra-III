﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Grbdatospersonales = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.TIPOIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IDENTIFICACIONDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NOMBREDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PRIMERAPELLIDODataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SEGUNDOAPELLIDODataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CORREOELECTRONICODataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FECHANACIMIENTODataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DIRECCIONDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SECUENCIADataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PERSONABindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Datos_CiudadanosDataSet = New Mi_primer_app.Datos_CiudadanosDataSet()
        Me.txtIdentificacion = New System.Windows.Forms.MaskedTextBox()
        Me.txtDireccion = New System.Windows.Forms.TextBox()
        Me.Lbldireccion = New System.Windows.Forms.Label()
        Me.Lblfechanacimiento = New System.Windows.Forms.Label()
        Me.Lblapellido2 = New System.Windows.Forms.Label()
        Me.Lblapellido1 = New System.Windows.Forms.Label()
        Me.Lblnombre = New System.Windows.Forms.Label()
        Me.Lblcorreo = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpfechanaci = New System.Windows.Forms.DateTimePicker()
        Me.txtCorreo = New System.Windows.Forms.TextBox()
        Me.txtSegundoApellido = New System.Windows.Forms.TextBox()
        Me.txtPrimerApellido = New System.Windows.Forms.TextBox()
        Me.txtNombre = New System.Windows.Forms.TextBox()
        Me.Cmbtipoid = New System.Windows.Forms.ComboBox()
        Me.btninsertar = New System.Windows.Forms.Button()
        Me.Btnconsultar = New System.Windows.Forms.Button()
        Me.Btnmodificar = New System.Windows.Forms.Button()
        Me.Btneliminar = New System.Windows.Forms.Button()
        Me.Btnsalir = New System.Windows.Forms.Button()
        Me.Txtfecha = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PERSONATableAdapter = New Mi_primer_app.Datos_CiudadanosDataSetTableAdapters.PERSONATableAdapter()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.Grbdatospersonales.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PERSONABindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Datos_CiudadanosDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Grbdatospersonales
        '
        Me.Grbdatospersonales.Controls.Add(Me.DataGridView1)
        Me.Grbdatospersonales.Controls.Add(Me.txtIdentificacion)
        Me.Grbdatospersonales.Controls.Add(Me.txtDireccion)
        Me.Grbdatospersonales.Controls.Add(Me.Lbldireccion)
        Me.Grbdatospersonales.Controls.Add(Me.Lblfechanacimiento)
        Me.Grbdatospersonales.Controls.Add(Me.Lblapellido2)
        Me.Grbdatospersonales.Controls.Add(Me.Lblapellido1)
        Me.Grbdatospersonales.Controls.Add(Me.Lblnombre)
        Me.Grbdatospersonales.Controls.Add(Me.Lblcorreo)
        Me.Grbdatospersonales.Controls.Add(Me.Label2)
        Me.Grbdatospersonales.Controls.Add(Me.Label1)
        Me.Grbdatospersonales.Controls.Add(Me.dtpfechanaci)
        Me.Grbdatospersonales.Controls.Add(Me.txtCorreo)
        Me.Grbdatospersonales.Controls.Add(Me.txtSegundoApellido)
        Me.Grbdatospersonales.Controls.Add(Me.txtPrimerApellido)
        Me.Grbdatospersonales.Controls.Add(Me.txtNombre)
        Me.Grbdatospersonales.Controls.Add(Me.Cmbtipoid)
        Me.Grbdatospersonales.Font = New System.Drawing.Font("Segoe UI Emoji", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Grbdatospersonales.Location = New System.Drawing.Point(12, 107)
        Me.Grbdatospersonales.Name = "Grbdatospersonales"
        Me.Grbdatospersonales.Size = New System.Drawing.Size(1144, 565)
        Me.Grbdatospersonales.TabIndex = 1
        Me.Grbdatospersonales.TabStop = False
        Me.Grbdatospersonales.Text = "Modificación de datos"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.TIPOIDDataGridViewTextBoxColumn, Me.IDENTIFICACIONDataGridViewTextBoxColumn, Me.NOMBREDataGridViewTextBoxColumn, Me.PRIMERAPELLIDODataGridViewTextBoxColumn, Me.SEGUNDOAPELLIDODataGridViewTextBoxColumn, Me.CORREOELECTRONICODataGridViewTextBoxColumn, Me.FECHANACIMIENTODataGridViewTextBoxColumn, Me.DIRECCIONDataGridViewTextBoxColumn, Me.SECUENCIADataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.PERSONABindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(6, 405)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(1188, 142)
        Me.DataGridView1.TabIndex = 19
        '
        'TIPOIDDataGridViewTextBoxColumn
        '
        Me.TIPOIDDataGridViewTextBoxColumn.DataPropertyName = "TIPO_ID"
        Me.TIPOIDDataGridViewTextBoxColumn.HeaderText = "TIPO_ID"
        Me.TIPOIDDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.TIPOIDDataGridViewTextBoxColumn.Name = "TIPOIDDataGridViewTextBoxColumn"
        Me.TIPOIDDataGridViewTextBoxColumn.Width = 125
        '
        'IDENTIFICACIONDataGridViewTextBoxColumn
        '
        Me.IDENTIFICACIONDataGridViewTextBoxColumn.DataPropertyName = "IDENTIFICACION"
        Me.IDENTIFICACIONDataGridViewTextBoxColumn.HeaderText = "IDENTIFICACION"
        Me.IDENTIFICACIONDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.IDENTIFICACIONDataGridViewTextBoxColumn.Name = "IDENTIFICACIONDataGridViewTextBoxColumn"
        Me.IDENTIFICACIONDataGridViewTextBoxColumn.Width = 125
        '
        'NOMBREDataGridViewTextBoxColumn
        '
        Me.NOMBREDataGridViewTextBoxColumn.DataPropertyName = "NOMBRE"
        Me.NOMBREDataGridViewTextBoxColumn.HeaderText = "NOMBRE"
        Me.NOMBREDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.NOMBREDataGridViewTextBoxColumn.Name = "NOMBREDataGridViewTextBoxColumn"
        Me.NOMBREDataGridViewTextBoxColumn.Width = 125
        '
        'PRIMERAPELLIDODataGridViewTextBoxColumn
        '
        Me.PRIMERAPELLIDODataGridViewTextBoxColumn.DataPropertyName = "PRIMER_APELLIDO"
        Me.PRIMERAPELLIDODataGridViewTextBoxColumn.HeaderText = "1er_APELLIDO"
        Me.PRIMERAPELLIDODataGridViewTextBoxColumn.MinimumWidth = 6
        Me.PRIMERAPELLIDODataGridViewTextBoxColumn.Name = "PRIMERAPELLIDODataGridViewTextBoxColumn"
        Me.PRIMERAPELLIDODataGridViewTextBoxColumn.Width = 125
        '
        'SEGUNDOAPELLIDODataGridViewTextBoxColumn
        '
        Me.SEGUNDOAPELLIDODataGridViewTextBoxColumn.DataPropertyName = "SEGUNDO_APELLIDO"
        Me.SEGUNDOAPELLIDODataGridViewTextBoxColumn.HeaderText = "2do_APELLIDO"
        Me.SEGUNDOAPELLIDODataGridViewTextBoxColumn.MinimumWidth = 6
        Me.SEGUNDOAPELLIDODataGridViewTextBoxColumn.Name = "SEGUNDOAPELLIDODataGridViewTextBoxColumn"
        Me.SEGUNDOAPELLIDODataGridViewTextBoxColumn.Width = 125
        '
        'CORREOELECTRONICODataGridViewTextBoxColumn
        '
        Me.CORREOELECTRONICODataGridViewTextBoxColumn.DataPropertyName = "CORREO_ELECTRONICO"
        Me.CORREOELECTRONICODataGridViewTextBoxColumn.HeaderText = "CORREO"
        Me.CORREOELECTRONICODataGridViewTextBoxColumn.MinimumWidth = 6
        Me.CORREOELECTRONICODataGridViewTextBoxColumn.Name = "CORREOELECTRONICODataGridViewTextBoxColumn"
        Me.CORREOELECTRONICODataGridViewTextBoxColumn.Width = 125
        '
        'FECHANACIMIENTODataGridViewTextBoxColumn
        '
        Me.FECHANACIMIENTODataGridViewTextBoxColumn.DataPropertyName = "FECHA_NACIMIENTO"
        Me.FECHANACIMIENTODataGridViewTextBoxColumn.HeaderText = "F_NACIMIENTO"
        Me.FECHANACIMIENTODataGridViewTextBoxColumn.MinimumWidth = 6
        Me.FECHANACIMIENTODataGridViewTextBoxColumn.Name = "FECHANACIMIENTODataGridViewTextBoxColumn"
        Me.FECHANACIMIENTODataGridViewTextBoxColumn.Width = 50
        '
        'DIRECCIONDataGridViewTextBoxColumn
        '
        Me.DIRECCIONDataGridViewTextBoxColumn.DataPropertyName = "DIRECCION"
        Me.DIRECCIONDataGridViewTextBoxColumn.HeaderText = "DIRECCION"
        Me.DIRECCIONDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.DIRECCIONDataGridViewTextBoxColumn.Name = "DIRECCIONDataGridViewTextBoxColumn"
        Me.DIRECCIONDataGridViewTextBoxColumn.Width = 125
        '
        'SECUENCIADataGridViewTextBoxColumn
        '
        Me.SECUENCIADataGridViewTextBoxColumn.DataPropertyName = "SECUENCIA"
        Me.SECUENCIADataGridViewTextBoxColumn.HeaderText = "SECUENCIA"
        Me.SECUENCIADataGridViewTextBoxColumn.MinimumWidth = 6
        Me.SECUENCIADataGridViewTextBoxColumn.Name = "SECUENCIADataGridViewTextBoxColumn"
        Me.SECUENCIADataGridViewTextBoxColumn.ReadOnly = True
        Me.SECUENCIADataGridViewTextBoxColumn.Width = 125
        '
        'PERSONABindingSource
        '
        Me.PERSONABindingSource.DataMember = "PERSONA"
        Me.PERSONABindingSource.DataSource = Me.Datos_CiudadanosDataSet
        '
        'Datos_CiudadanosDataSet
        '
        Me.Datos_CiudadanosDataSet.DataSetName = "Datos_CiudadanosDataSet"
        Me.Datos_CiudadanosDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtIdentificacion
        '
        Me.txtIdentificacion.Location = New System.Drawing.Point(296, 96)
        Me.txtIdentificacion.Name = "txtIdentificacion"
        Me.txtIdentificacion.Size = New System.Drawing.Size(252, 34)
        Me.txtIdentificacion.TabIndex = 1
        '
        'txtDireccion
        '
        Me.txtDireccion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDireccion.Location = New System.Drawing.Point(621, 278)
        Me.txtDireccion.Multiline = True
        Me.txtDireccion.Name = "txtDireccion"
        Me.txtDireccion.Size = New System.Drawing.Size(469, 72)
        Me.txtDireccion.TabIndex = 7
        '
        'Lbldireccion
        '
        Me.Lbldireccion.AutoSize = True
        Me.Lbldireccion.Location = New System.Drawing.Point(616, 238)
        Me.Lbldireccion.Name = "Lbldireccion"
        Me.Lbldireccion.Size = New System.Drawing.Size(103, 27)
        Me.Lbldireccion.TabIndex = 14
        Me.Lbldireccion.Text = "Dirección"
        '
        'Lblfechanacimiento
        '
        Me.Lblfechanacimiento.AutoSize = True
        Me.Lblfechanacimiento.Location = New System.Drawing.Point(24, 232)
        Me.Lblfechanacimiento.Name = "Lblfechanacimiento"
        Me.Lblfechanacimiento.Size = New System.Drawing.Size(210, 27)
        Me.Lblfechanacimiento.TabIndex = 13
        Me.Lblfechanacimiento.Text = "Fecha de nacimiento"
        '
        'Lblapellido2
        '
        Me.Lblapellido2.AutoSize = True
        Me.Lblapellido2.Location = New System.Drawing.Point(616, 150)
        Me.Lblapellido2.Name = "Lblapellido2"
        Me.Lblapellido2.Size = New System.Drawing.Size(186, 27)
        Me.Lblapellido2.TabIndex = 12
        Me.Lblapellido2.Text = "Segundo Apellido"
        '
        'Lblapellido1
        '
        Me.Lblapellido1.AutoSize = True
        Me.Lblapellido1.Location = New System.Drawing.Point(293, 154)
        Me.Lblapellido1.Name = "Lblapellido1"
        Me.Lblapellido1.Size = New System.Drawing.Size(163, 27)
        Me.Lblapellido1.TabIndex = 11
        Me.Lblapellido1.Text = "Primer Apellido"
        '
        'Lblnombre
        '
        Me.Lblnombre.AutoSize = True
        Me.Lblnombre.Location = New System.Drawing.Point(24, 154)
        Me.Lblnombre.Name = "Lblnombre"
        Me.Lblnombre.Size = New System.Drawing.Size(91, 27)
        Me.Lblnombre.TabIndex = 10
        Me.Lblnombre.Text = "Nombre"
        '
        'Lblcorreo
        '
        Me.Lblcorreo.AutoSize = True
        Me.Lblcorreo.Location = New System.Drawing.Point(616, 56)
        Me.Lblcorreo.Name = "Lblcorreo"
        Me.Lblcorreo.Size = New System.Drawing.Size(192, 27)
        Me.Lblcorreo.TabIndex = 9
        Me.Lblcorreo.Text = "Correo Electrónico"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(293, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(143, 27)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Identificación"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(222, 27)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Tipo de identificación"
        '
        'dtpfechanaci
        '
        Me.dtpfechanaci.Location = New System.Drawing.Point(27, 275)
        Me.dtpfechanaci.Name = "dtpfechanaci"
        Me.dtpfechanaci.Size = New System.Drawing.Size(409, 34)
        Me.dtpfechanaci.TabIndex = 6
        '
        'txtCorreo
        '
        Me.txtCorreo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCorreo.Location = New System.Drawing.Point(621, 98)
        Me.txtCorreo.Name = "txtCorreo"
        Me.txtCorreo.Size = New System.Drawing.Size(429, 34)
        Me.txtCorreo.TabIndex = 2
        '
        'txtSegundoApellido
        '
        Me.txtSegundoApellido.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSegundoApellido.Location = New System.Drawing.Point(621, 187)
        Me.txtSegundoApellido.Name = "txtSegundoApellido"
        Me.txtSegundoApellido.Size = New System.Drawing.Size(246, 34)
        Me.txtSegundoApellido.TabIndex = 5
        '
        'txtPrimerApellido
        '
        Me.txtPrimerApellido.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPrimerApellido.Location = New System.Drawing.Point(296, 187)
        Me.txtPrimerApellido.Name = "txtPrimerApellido"
        Me.txtPrimerApellido.Size = New System.Drawing.Size(233, 34)
        Me.txtPrimerApellido.TabIndex = 4
        '
        'txtNombre
        '
        Me.txtNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNombre.Location = New System.Drawing.Point(27, 187)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(197, 34)
        Me.txtNombre.TabIndex = 3
        '
        'Cmbtipoid
        '
        Me.Cmbtipoid.FormattingEnabled = True
        Me.Cmbtipoid.Items.AddRange(New Object() {"Nacional", "Dimex", "Pasaporte"})
        Me.Cmbtipoid.Location = New System.Drawing.Point(27, 96)
        Me.Cmbtipoid.Name = "Cmbtipoid"
        Me.Cmbtipoid.Size = New System.Drawing.Size(142, 35)
        Me.Cmbtipoid.TabIndex = 0
        '
        'btninsertar
        '
        Me.btninsertar.FlatAppearance.BorderSize = 0
        Me.btninsertar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btninsertar.Font = New System.Drawing.Font("Segoe UI Emoji", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btninsertar.Image = CType(resources.GetObject("btninsertar.Image"), System.Drawing.Image)
        Me.btninsertar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btninsertar.Location = New System.Drawing.Point(1193, 171)
        Me.btninsertar.Name = "btninsertar"
        Me.btninsertar.Size = New System.Drawing.Size(136, 44)
        Me.btninsertar.TabIndex = 2
        Me.btninsertar.Text = "Agregar"
        Me.btninsertar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btninsertar.UseVisualStyleBackColor = True
        '
        'Btnconsultar
        '
        Me.Btnconsultar.FlatAppearance.BorderSize = 0
        Me.Btnconsultar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnconsultar.Font = New System.Drawing.Font("Segoe UI Emoji", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnconsultar.Image = CType(resources.GetObject("Btnconsultar.Image"), System.Drawing.Image)
        Me.Btnconsultar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btnconsultar.Location = New System.Drawing.Point(1193, 236)
        Me.Btnconsultar.Name = "Btnconsultar"
        Me.Btnconsultar.Size = New System.Drawing.Size(136, 44)
        Me.Btnconsultar.TabIndex = 3
        Me.Btnconsultar.Text = "Buscar"
        Me.Btnconsultar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btnconsultar.UseVisualStyleBackColor = True
        '
        'Btnmodificar
        '
        Me.Btnmodificar.FlatAppearance.BorderSize = 0
        Me.Btnmodificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnmodificar.Font = New System.Drawing.Font("Segoe UI Emoji", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnmodificar.Image = CType(resources.GetObject("Btnmodificar.Image"), System.Drawing.Image)
        Me.Btnmodificar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btnmodificar.Location = New System.Drawing.Point(1193, 296)
        Me.Btnmodificar.Name = "Btnmodificar"
        Me.Btnmodificar.Size = New System.Drawing.Size(136, 44)
        Me.Btnmodificar.TabIndex = 4
        Me.Btnmodificar.Text = "Editar"
        Me.Btnmodificar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btnmodificar.UseVisualStyleBackColor = True
        '
        'Btneliminar
        '
        Me.Btneliminar.FlatAppearance.BorderSize = 0
        Me.Btneliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btneliminar.Font = New System.Drawing.Font("Segoe UI Emoji", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btneliminar.Image = CType(resources.GetObject("Btneliminar.Image"), System.Drawing.Image)
        Me.Btneliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btneliminar.Location = New System.Drawing.Point(1193, 360)
        Me.Btneliminar.Name = "Btneliminar"
        Me.Btneliminar.Size = New System.Drawing.Size(136, 44)
        Me.Btneliminar.TabIndex = 5
        Me.Btneliminar.Text = "Eliminar"
        Me.Btneliminar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btneliminar.UseVisualStyleBackColor = True
        '
        'Btnsalir
        '
        Me.Btnsalir.FlatAppearance.BorderSize = 0
        Me.Btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnsalir.Font = New System.Drawing.Font("Segoe UI Emoji", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnsalir.Image = CType(resources.GetObject("Btnsalir.Image"), System.Drawing.Image)
        Me.Btnsalir.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btnsalir.Location = New System.Drawing.Point(1193, 425)
        Me.Btnsalir.Name = "Btnsalir"
        Me.Btnsalir.Size = New System.Drawing.Size(136, 44)
        Me.Btnsalir.TabIndex = 6
        Me.Btnsalir.Text = "Inicio"
        Me.Btnsalir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btnsalir.UseVisualStyleBackColor = True
        '
        'Txtfecha
        '
        Me.Txtfecha.Font = New System.Drawing.Font("Segoe UI Emoji", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtfecha.Location = New System.Drawing.Point(971, -33)
        Me.Txtfecha.Name = "Txtfecha"
        Me.Txtfecha.Size = New System.Drawing.Size(295, 34)
        Me.Txtfecha.TabIndex = 7
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'PERSONATableAdapter
        '
        Me.PERSONATableAdapter.ClearBeforeFill = True
        '
        'btnLimpiar
        '
        Me.btnLimpiar.FlatAppearance.BorderSize = 0
        Me.btnLimpiar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLimpiar.Font = New System.Drawing.Font("Segoe UI Emoji", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLimpiar.Image = CType(resources.GetObject("btnLimpiar.Image"), System.Drawing.Image)
        Me.btnLimpiar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnLimpiar.Location = New System.Drawing.Point(1193, 489)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(136, 44)
        Me.btnLimpiar.TabIndex = 8
        Me.btnLimpiar.Text = "Borar"
        Me.btnLimpiar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLimpiar.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1378, 673)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Controls.Add(Me.Txtfecha)
        Me.Controls.Add(Me.Btnsalir)
        Me.Controls.Add(Me.Btneliminar)
        Me.Controls.Add(Me.Btnmodificar)
        Me.Controls.Add(Me.Btnconsultar)
        Me.Controls.Add(Me.btninsertar)
        Me.Controls.Add(Me.Grbdatospersonales)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "Captura de datos personales de ciudadanos que Residen en Costa Rica"
        Me.Grbdatospersonales.ResumeLayout(False)
        Me.Grbdatospersonales.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PERSONABindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Datos_CiudadanosDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Grbdatospersonales As GroupBox
    Friend WithEvents Cmbtipoid As ComboBox
    Friend WithEvents Lblcorreo As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents dtpfechanaci As DateTimePicker
    Friend WithEvents txtCorreo As TextBox
    Friend WithEvents txtSegundoApellido As TextBox
    Friend WithEvents txtPrimerApellido As TextBox
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtDireccion As TextBox
    Friend WithEvents Lbldireccion As Label
    Friend WithEvents Lblfechanacimiento As Label
    Friend WithEvents Lblapellido2 As Label
    Friend WithEvents Lblapellido1 As Label
    Friend WithEvents Lblnombre As Label
    Friend WithEvents btninsertar As Button
    Friend WithEvents Btnconsultar As Button
    Friend WithEvents Btnmodificar As Button
    Friend WithEvents Btneliminar As Button
    Friend WithEvents Btnsalir As Button
    Friend WithEvents txtIdentificacion As MaskedTextBox
    Friend WithEvents Txtfecha As TextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Datos_CiudadanosDataSet As Datos_CiudadanosDataSet
    Friend WithEvents PERSONABindingSource As BindingSource
    Friend WithEvents PERSONATableAdapter As Datos_CiudadanosDataSetTableAdapters.PERSONATableAdapter
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents TIPOIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents IDENTIFICACIONDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NOMBREDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PRIMERAPELLIDODataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SEGUNDOAPELLIDODataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CORREOELECTRONICODataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FECHANACIMIENTODataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DIRECCIONDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SECUENCIADataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
