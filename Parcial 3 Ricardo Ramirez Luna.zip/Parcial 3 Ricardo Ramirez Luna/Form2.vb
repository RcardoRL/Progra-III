﻿Public Class Form2
    Private Sub Btnsalir_Click(sender As Object, e As EventArgs) Handles Btnsalir.Click
        Me.Close()
        FrmMenu.Show()
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        txtIdentificacion.Clear()
        txtCorreo.Clear()
        txtNombre.Clear()
        txtPrimerApellido.Clear()
        txtSegundoApellido.Clear()
        txtDireccion.Clear()
    End Sub

    Private Sub Cmbtipoid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cmbtipoid.SelectedIndexChanged
        txtIdentificacion.Text = ""
        If Cmbtipoid.Text = "Nacional" Then
            ntipoid = 1
            txtIdentificacion.Mask = "9-9999-9999"
            SendKeys.Send("{tab}")   'Envía un tab al siguiente campo

        ElseIf Cmbtipoid.Text = "Dimex" Then
            ntipoid = 2
            txtIdentificacion.Mask = "999999999999"
            SendKeys.Send("{tab}")

        ElseIf Cmbtipoid.Text = "Pasaporte" Then
            ntipoid = 3
            txtIdentificacion.Mask = "AAAAAAAAAAAAAAAAAAAA"
            SendKeys.Send("{tab}")
        End If
    End Sub

    Private Sub BtnConsultar_Click(sender As Object, e As EventArgs) Handles BtnConsultar.Click
        Try
            If Cmbtipoid.Text = "" Or txtIdentificacion.MaskFull = False Then
                MsgBox("Datos Incompletos, favor completar")
                Return
            End If
            Dim vtipoid, videntificacion As String
            Dim valorformateado As String
            vtipoid = ""
            videntificacion = ""
            valorformateado = txtIdentificacion.Text
            Dim valorsinformato As String = valorformateado.Replace("-", "")
            videntificacion = valorsinformato
            vtipoid = Cmbtipoid.Text
            If valorsinformato.Trim <> "" Then

                Dim conexion As New Conexion()
                conexion.Conexion.Open()

                Dim dt = conexion.valida_id(vtipoid, videntificacion)
                If f = 1 Then
                    MsgBox("Número de identificacion no existe en la Base de Datos")
                    txtIdentificacion.Focus()
                    Return
                Else
                    k = 1
                    txtNombre.Text = dt.Rows(0)!nombre
                    txtPrimerApellido.Text = dt.Rows(0)!primer_apellido
                    txtSegundoApellido.Text = dt.Rows(0)!segundo_apellido
                    txtCorreo.Text = dt.Rows(0)!correo_electronico
                    dtpfechanaci.Value = dt.Rows(0)!fecha_nacimiento
                    txtDireccion.Text = dt.Rows(0)!direccion
                End If
                conexion.Conexion.Close()
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " + ex.ToString)
        End Try
    End Sub

    Private Sub Grbdatospersonales_Enter(sender As Object, e As EventArgs) Handles Grbdatospersonales.Enter
        Me.ControlBox = False
    End Sub

End Class