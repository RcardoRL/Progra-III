﻿Public Class FrmMenu
    Private Sub InclusiónDeCódigoUsuarioYClaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InclusiónDeCódigoUsuarioYClaveToolStripMenuItem.Click
        Login.Show()
    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Dim resultado As DialogResult
        resultado = MessageBox.Show("Desea abandonar el Sistema?", "Abandonar sistema", MessageBoxButtons.YesNo)
        Try
            If (resultado = DialogResult.Yes) Then
                Me.Close()
                Application.Exit()
            Else

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    ' Muesta hora y fecha actual
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        txtFecha.Text = Now
    End Sub

    ' Se carga los datos registrados en la Base de datos en el control Box
    Private Sub FrmMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.ControlBox = False
    End Sub
    Private Sub ConsulaDeCiudadanoToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles ConsulaDeCiudadanoToolStripMenuItem.Click
        Form2.Show()
    End Sub

    Private Sub BtnVote_Click(sender As Object, e As EventArgs) Handles BtnVote.Click
        Formulario_para_Votar.Show()
    End Sub

    Private Sub ModificaciónDeDatosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ModificaciónDeDatosToolStripMenuItem.Click
        Form1.Show()
    End Sub

End Class