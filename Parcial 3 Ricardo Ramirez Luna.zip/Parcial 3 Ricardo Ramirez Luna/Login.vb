﻿Public Class Login
    Dim Conexion As Conexion = New Conexion()
    Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click
        Dim vusuario, vclave, strsql As String
        vusuario = txtUsuario.Text
        vclave = txtContraseña.Text
        strsql = ""
        If txtUsuario.Text = "" Or txtContraseña.Text = "" Then
            MsgBox("Todos los datos son obligatorios")
            txtUsuario.Focus()
            Return
        End If
        If Conexion.valida_usuario(vusuario) Then
            Dim contraseñaAlmacenada As String = Conexion.Desencriptar_clave(vclave)
            MessageBox.Show("El usuario ya existe y la contraseña es: " + contraseñaAlmacenada, "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        'Emcriptar clave
        Dim clave_encriptada As String = Conexion.Encriptar_clave(vclave)
        'Creamos el INSERT
        strsql = "INSERT INTO USUARIO (USUARIO, CLAVE)"
        strsql += vbCrLf + "VALUES ('" & vusuario & "','" & clave_encriptada & "')"
        MsgBox(strsql)
        Conexion.inserta_datos(strsql)
        If f = 0 Then
            MessageBox.Show("Datos almacenados satisfactoriamente", "Datos guardados", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtContraseña.Clear()
            txtUsuario.Clear()
        Else
            MessageBox.Show("Error al insertar datos", "Datos no guardados", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
        txtUsuario.Focus()
    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        Me.Close()
        FrmMenu.Show()
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.ControlBox = False
    End Sub
End Class